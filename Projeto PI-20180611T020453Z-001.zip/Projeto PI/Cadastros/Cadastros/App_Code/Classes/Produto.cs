﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cadastros.Classes
{
    /// <summary>
    /// Summary description for Funcionario
    /// </summary>
    public class Produto
    {
        //propriedades
        public int Codigo { get; set; }
        public string Nome { get; set; }
        
        //construtor
        public Produto()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}
